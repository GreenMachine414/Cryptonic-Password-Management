gem install dpl >/dev/null
gem install faraday -v 1.8.0 >/dev/null
