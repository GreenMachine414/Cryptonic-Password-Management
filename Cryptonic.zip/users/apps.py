"""App configuration."""
from django.apps import AppConfig


class UsersConfig(AppConfig):
    """User App configuration."""

    name = "users"
